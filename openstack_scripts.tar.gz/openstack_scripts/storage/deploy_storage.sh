#!/bin/bash

set -x

deploy_init() {
add-apt-repository -y cloud-archive:train
apt -y update && apt -y dist-upgrade
apt -y install python3-openstackclient
}

deploy_storage () {

apt -y install lvm2 thin-provisioning-tools cinder-volume

cp configs/cinder.conf /etc/cinder/cinder.conf

pvcreate /dev/sdb
vgcreate cinder-volumes /dev/sdb

systemctl restart tgt cinder-volume
}

for arg in "$@"; do
    deploy_$arg
done

