#!/bin/bash

set -x

apt install bridge-utils
brctl addbr br-baremetal
brctl addif br-baremetal eth4
sudo ifconfig  eth4 up
sudo ifconfig  br-baremetal  up

