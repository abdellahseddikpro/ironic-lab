#!/bin/bash

set -x

deploy_init() {
add-apt-repository -y cloud-archive:train
apt -y update && apt  -y dist-upgrade
apt -y install python3-openstackclient
}
deploy_compute() {
apt -y install nova-compute libvirt-bin  python3-libvirt python-lxml  python3-lxml  python-libvirt 
cp configs/nova.conf /etc/nova/nova.conf 
cp configs/nova-compute.conf /etc/nova/nova-compute.conf 

systemctl restart nova-compute
}
deploy_neutron() {
apt install -y  neutron-plugin-ml2  neutron-openvswitch-agent python3-ryu openvswitch-common  bridge-utils

cp configs/neutron.conf       /etc/neutron/neutron.conf
cp configs/ml2_conf.ini       /etc/neutron/plugins/ml2/ml2_conf.ini
cp configs/ml2_conf.ini       /etc/neutron/plugins/ml2/openvswitch_agent.ini
cp configs/ml2_conf.ini       /etc/neutron/plugins/plugin.ini
cp configs/neutron.sudoers    /etc/sudoers.d/neutron
systemctl restart neutron-openvswitch-agent
}
for arg in "$@"; do
    deploy_$arg
done

