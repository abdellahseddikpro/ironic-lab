export OS_USERNAME=admin
export OS_PASSWORD=adminpass
export OS_PROJECT_NAME=admin
export OS_USER_DOMAIN_NAME=Default
export OS_PROJECT_DOMAIN_NAME=Default
export OS_AUTH_URL=http://openstack.example.org:5000/v3
export OS_IDENTITY_API_VERSION=3
