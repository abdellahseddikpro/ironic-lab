#!/bin/bash

set -x

deploy_init() {
add-apt-repository -y cloud-archive:train
apt -y update && apt -y dist-upgrade
apt -y install python3-openstackclient
}
deploy_mysql() {
apt -y install mariadb-server python-pymysql
cp configs/mariadb.cnf  /etc/mysql/mariadb.conf.d/99-openstack.cnf 
systemctl restart mariadb
}
deploy_rabbitmq() {
apt -y install rabbitmq-server
rabbitmqctl add_user openstack openstack
rabbitmqctl set_permissions openstack ".*" ".*" ".*"
}

deploy_memcache() {
apt -y install memcached python-memcache
cp  configs/memcached.conf  /etc/memcached.conf 
systemctl restart memcached
}
deploy_keystone() {
    mysql -uroot <<EOF
DROP DATABASE IF EXISTS keystone;
CREATE DATABASE keystone;
GRANT ALL ON keystone.* TO 'keystone'@'localhost' IDENTIFIED BY 'keystonedbpass';
GRANT ALL ON keystone.* TO 'keystone'@'controller' IDENTIFIED BY 'keystonedbpass';
GRANT ALL ON keystone.* TO 'keystone'@'%' IDENTIFIED BY 'keystonedbpass';
EOF

apt -y install keystone
cp  configs/keystone.conf /etc/keystone/keystone.conf 

su -s /bin/sh -c "keystone-manage db_sync" keystone
keystone-manage fernet_setup --keystone-user keystone --keystone-group keystone
keystone-manage credential_setup --keystone-user keystone --keystone-group keystone
openstack project create service

keystone-manage bootstrap --bootstrap-password adminpass \
  --bootstrap-admin-url http://openstack.example.org:5000/v3/ \
  --bootstrap-internal-url http://openstack.example.org:5000/v3/ \
  --bootstrap-public-url http://openstack.example.org:5000/v3/ \
  --bootstrap-region-id RegionOne

service apache2 restart
cp  configs/admin.sh ~/admin.sh 

}

deploy_cred () {
cp  configs/admin.sh ~/admin.sh 
}

deploy_glance () {

source ~/admin.sh

    mysql -uroot <<EOF
DROP DATABASE IF EXISTS glance;
CREATE DATABASE glance;
GRANT ALL ON glance.* TO 'glance'@'localhost' IDENTIFIED BY 'glancedbpass';
GRANT ALL ON glance.* TO 'glance'@'controller' IDENTIFIED BY 'glancedbpass';
GRANT ALL ON glance.* TO 'glance'@'%' IDENTIFIED BY 'glancedbpass';
EOF

openstack project create service
openstack user create --domain default --password glancepass glance
openstack role add --project service --user glance admin
openstack service create --name glance --description "OpenStack Image" image
openstack endpoint create --region RegionOne image public http://openstack.example.org:9292
openstack endpoint create --region RegionOne image internal http://openstack.example.org:9292
openstack endpoint create --region RegionOne image admin http://openstack.example.org:9292

apt -y install glance
cp configs/glance-api.conf /etc/glance/glance-api.conf 
su -s /bin/sh -c "glance-manage db_sync" glance
service glance-api restart
wget -O cirros-0.3.6-i386-disk.img \
      http://download.cirros-cloud.net/0.3.6/cirros-0.3.6-i386-disk.img
openstack image create --file  cirros-0.3.6-i386-disk.img  cirros
}

deploy_placement () {

 source ~/admin.sh
 mysql -uroot <<EOF
DROP DATABASE IF EXISTS placement;
CREATE DATABASE placement;
GRANT ALL ON placement.* TO 'placement'@'localhost' IDENTIFIED BY 'placementdbpass';
GRANT ALL ON placement.* TO 'placement'@'controller' IDENTIFIED BY 'placementdbpass';
GRANT ALL ON placement.* TO 'placement'@'%' IDENTIFIED BY 'placementdbpass';
EOF

# Create User, service and endpoint. Attach role to created user 
openstack project create service
openstack user create --domain default --password placementpass placement
openstack role add --project service --user placement admin
openstack service create --name placement --description "Placement API" placement
openstack endpoint create --region RegionOne placement public http://openstack.example.org:8778
openstack endpoint create --region RegionOne placement internal http://openstack.example.org:8778
openstack endpoint create --region RegionOne placement admin http://openstack.example.org:8778

apt -y install placement-api
cp configs/placement.conf /etc/placement/placement.conf 

su -s /bin/sh -c "placement-manage db sync" placement
service apache2 restart
}

deploy_nova () {

 source ~/admin.sh

# Create DB with right privilages 
 mysql -uroot <<EOF
DROP DATABASE IF EXISTS nova_api;
DROP DATABASE IF EXISTS nova;
DROP DATABASE IF EXISTS nova_cell0;

CREATE DATABASE nova_api;
CREATE DATABASE nova;
CREATE DATABASE nova_cell0;

GRANT ALL ON nova.* TO 'nova'@'localhost' IDENTIFIED BY 'novadbpass';
GRANT ALL ON nova.* TO 'nova'@'controller' IDENTIFIED BY 'novadbpass';
GRANT ALL ON nova.* TO 'nova'@'%' IDENTIFIED BY 'novadbpass';

GRANT ALL ON nova_api.* TO 'nova'@'localhost' IDENTIFIED BY 'novadbpass';
GRANT ALL ON nova_api.* TO 'nova'@'controller' IDENTIFIED BY 'novadbpass';
GRANT ALL ON nova_api.* TO 'nova'@'%' IDENTIFIED BY 'novadbpass';

GRANT ALL ON nova_cell0.* TO 'nova'@'localhost' IDENTIFIED BY 'novadbpass';
GRANT ALL ON nova_cell0.* TO 'nova'@'controller' IDENTIFIED BY 'novadbpass';
GRANT ALL ON nova_cell0.* TO 'nova'@'%' IDENTIFIED BY 'novadbpass';
EOF

# Create User, service and endpoint. Attach role to created user 
openstack project create service
openstack user create --domain default --password novapass nova
openstack role add --project service --user nova admin
openstack service create --name nova --description "OpenStack Compute" compute
openstack endpoint create --region RegionOne compute public http://openstack.example.org:8774/v2.1
openstack endpoint create --region RegionOne compute internal http://openstack.example.org:8774/v2.1
openstack endpoint create --region RegionOne compute admin http://openstack.example.org:8774/v2.1

# Install Packages
apt install -y nova-api nova-conductor nova-novncproxy nova-scheduler nova-compute

#Copy configuration file
cp configs/nova.conf /etc/nova/nova.conf 
rm /etc/nova/nova-compute.conf 
# Bootstrap Database
su -s /bin/sh -c "nova-manage api_db sync" nova
su -s /bin/sh -c "nova-manage cell_v2 create_cell --name=cell1 --verbose" nova
su -s /bin/sh -c "nova-manage db sync" nova

# Restart Services 
systemctl restart nova-api nova-scheduler nova-conductor nova-novncproxy nova-compute 
}

deploy_cinder () {

 source ~/admin.sh
# Create DB with right privilages 
    mysql -uroot <<EOF
DROP DATABASE IF EXISTS cinder;
CREATE DATABASE cinder;
GRANT ALL ON cinder.* TO 'cinder'@'localhost' IDENTIFIED BY 'cinderdbpass';
GRANT ALL ON cinder.* TO 'cinder'@'controller' IDENTIFIED BY 'cinderdbpass';
GRANT ALL ON cinder.* TO 'cinder'@'%' IDENTIFIED BY 'cinderdbpass';
EOF

# Create User, service and endpoint. Attach role to created user 
openstack project create service
openstack user create --domain default --password cinderpass cinder
openstack role add --project service --user cinder admin
openstack service create --name cinderv2 --description "OpenStack Block Storage" volumev2
openstack service create --name cinderv3 --description "OpenStack Block Storage" volumev3
openstack endpoint create --region RegionOne volumev2 public http://openstack.example.org:8776/v2/%\(project_id\)s
openstack endpoint create --region RegionOne volumev2 internal http://openstack.example.org:8776/v2/%\(project_id\)s
openstack endpoint create --region RegionOne volumev2 admin http://openstack.example.org:8776/v2/%\(project_id\)s
openstack endpoint create --region RegionOne volumev3 public http://openstack.example.org:8776/v3/%\(project_id\)s
openstack endpoint create --region RegionOne volumev3 internal http://openstack.example.org:8776/v3/%\(project_id\)s
openstack endpoint create --region RegionOne volumev3 admin http://openstack.example.org:8776/v3/%\(project_id\)s

# Install Packages
apt install -y cinder-api cinder-scheduler

# Copy new configuration file
cp configs/cinder.conf /etc/cinder/cinder.conf

# Bootstrap Database
su -s /bin/sh -c "cinder-manage db sync" cinder

# Restart Services
systemctl  restart nova-api cinder-scheduler apache2 
}

deploy_network () {

# Create Bridge FIP
ovs-vsctl add-br br-ex
ovs-vsctl add-port  br-ex eth3

# Create Bridge Baremetal
ovs-vsctl add-br br-baremetal
ovs-vsctl add-port  br-baremetal eth4

ip addr add 192.168.145.50/24 dev br-baremetal
ip link set dev eth4 up
ip link set dev eth3 up
ip link set dev br-baremetal up

}

deploy_neutron () {

 source ~/admin.sh
# Create DB with right privilages 
    mysql -uroot <<EOF
DROP DATABASE IF EXISTS neutron;
CREATE DATABASE neutron;
GRANT ALL ON neutron.* TO 'neutron'@'localhost' IDENTIFIED BY 'neutrondbpass';
GRANT ALL ON neutron.* TO 'neutron'@'controller' IDENTIFIED BY 'neutrondbpass';
GRANT ALL ON neutron.* TO 'neutron'@'%' IDENTIFIED BY 'neutrondbpass';
EOF

# Create User, service and endpoint. Attach role to created user 
openstack project create service
openstack user create --domain default --password neutronpass neutron
openstack role add --project service --user neutron admin
openstack service create --name neutron --description "OpenStack Networking" network

openstack endpoint create --region RegionOne network public http://openstack.example.org:9696
openstack endpoint create --region RegionOne network internal http://openstack.example.org:9696
openstack endpoint create --region RegionOne network admin http://openstack.example.org:9696

# Install Packages
apt install -y neutron-server neutron-plugin-ml2 \
  neutron-openvswitch-agent neutron-l3-agent neutron-dhcp-agent \
  neutron-metadata-agent openvswitch-common bridge-utils python3-ryu 

# Copy new configuration file
cp configs/neutron.conf       /etc/neutron/neutron.conf
cp configs/ml2_conf.ini       /etc/neutron/plugins/ml2/ml2_conf.ini
cp configs/ml2_conf.ini       /etc/neutron/plugins/ml2/openvswitch_agent.ini
cp configs/ml2_conf.ini       /etc/neutron/plugin.ini
cp configs/metadata_agent.ini /etc/neutron/metadata_agent.ini
cp configs/dhcp_agent.ini     /etc/neutron/dhcp_agent.ini
cp configs/l3_agent.ini       /etc/neutron/l3_agent.ini

#cp configs/ironic_neutron_agent.ini /etc/neutron/plugins/ml2/ironic_neutron_agent.ini 


# Bootstrap Database
su -s /bin/sh -c "neutron-db-manage --config-file /etc/neutron/neutron.conf \
  --config-file /etc/neutron/plugins/ml2/ml2_conf.ini upgrade head" neutron

# Restart Services
systemctl restart neutron-server neutron-dhcp-agent neutron-metadata-agent neutron-l3-agent neutron-openvswitch-agent

}

deploy_horizon () {

apt -y install openstack-dashboard
cp configs/local_settings.py         /etc/openstack-dashboard/local_settings.py 
cp  configs/openstack-dashboard.conf /etc/apache2/conf-available/openstack-dashboard.conf
systemctl reload apache2.service

}

deploy_ironic () {

 source ~/admin.sh

# Create DB with right privilages 
    mysql -uroot <<EOF
DROP DATABASE IF EXISTS ironic;
CREATE DATABASE ironic;
GRANT ALL ON ironic.* TO 'ironic'@'localhost' IDENTIFIED BY 'ironicdbpass';
GRANT ALL ON ironic.* TO 'ironic'@'controller' IDENTIFIED BY 'ironicdbpass';
GRANT ALL ON ironic.* TO 'ironic'@'%' IDENTIFIED BY 'ironicdbpass';
EOF

openstack user create --password ironicpass  ironic
openstack role add --project service --user ironic admin
openstack service create --name ironic --description \
    "Ironic baremetal provisioning service" baremetal
openstack endpoint create --region RegionOne \
  baremetal admin http://192.168.145.50:6385
openstack endpoint create --region RegionOne \
  baremetal public http://192.168.145.50:6385
openstack endpoint create --region RegionOne \
  baremetal internal http://192.168.145.50:6385

# I used 192.168.145.50 instead of the domain
# because i don't have routing and DNS server in the topology
# When the node startup in the first time it need to perfom  a callback to ironic IP
# Since we don't have that the callback  will fail
#openstack endpoint create --region RegionOne \
#  baremetal admin http://openstack.example.org:6385
#openstack endpoint create --region RegionOne \
#  baremetal public http://openstack.example.org:6385
#openstack endpoint create --region RegionOne \
#  baremetal internal http://openstack.example.org:6385

# Setup TFTP and HTTP 
apt-get -y install ipxe xinetd tftpd-hpa 


echo 'r ^([^/]) /tftpboot/\1' > /tftpboot/map-file
echo 'r ^(/tftpboot/) /tftpboot/\2' >> /tftpboot/map-file

cp configs/ipxe_http.conf /etc/apache2/sites-enabled/ironic_ipxe_httpboot.conf 
cp configs/tftp /etc/xinetd.d/tftp 
cp /usr/lib/ipxe/{undionly.kpxe,ipxe.efi} /tftpboot


# Install Ironic Packages
apt-get -y  install ironic-api ironic-conductor python3-ironicclient 

cp  configs/ironic.conf /etc/ironic/ironic.conf 
cp  configs/rootwrap.conf        /etc/ironic/rootwrap.conf
cp  configs/ironic-images.filters  /etc/ironic/rootwrap.d/ironic-images.filters
cp  configs/ironic-lib.filters  /etc/ironic/rootwrap.d/ironic-lib.filters
cp  configs/ironic-utils.filters  /etc/ironic/rootwrap.d/ironic-utils.filters

mkdir -p /tftpboot
mkdir -p /httpboot
chown -R ironic /tftpboot
chown -R ironic /httpboot
systemctl restart apache2 xinetd

ironic-dbsync --config-file /etc/ironic/ironic.conf create_schema

systemctl restart ironic-api nova-scheduler nova-compute ironic-conductor 
}

for arg in "$@"; do
    deploy_$arg
done
